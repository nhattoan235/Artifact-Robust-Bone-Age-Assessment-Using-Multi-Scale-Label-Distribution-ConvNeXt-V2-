# C3-Z26 C3-ROI artifact pilots B/C

## Protocol

Both pilots use the exact existing C3-Z26 Fold 1 split, seed 42, ConvNeXt-Tiny
with LDL head, and clean validation MAE for early stopping. They do not read the
RSNA test set and do not run TTA during selection.

* **B**: paired mild artifact augmentation, supervised loss on clean and artifact views.
* **C**: B plus `consistency_weight = 0.30`, penalizing prediction disagreement
  between the two views.

The training batch is 18 with gradient accumulation 2, so the effective clean
sample count remains 36 while the clean/artifact pair is processed together.
Each run has a unique ID and writes to `C3_Z26_C3_ROI_V2_PILOTS`; it cannot
overwrite the existing baseline or the LDL/seed pilots.

## Colab

1. Upload this ZIP to `MyDrive/RSNA_DATA/`.
2. Open `C3_Z26_C3_ROI_V2_PILOT_BC.ipynb` from the ZIP after extracting it, or
   copy its cells into a fresh Colab runtime.
3. Set `PILOT = 'B'`, run all cells, and wait for `RUN STATUS`.
4. Start a fresh runtime, change `PILOT = 'C'`, and repeat.

The input paths must already exist in the runtime:
`/content/C3_Z26_C3_ROI_V2/manifests/` and `/content/C3_Z26_COMBO_V2/`.
Checkpoints and logs are mirrored to `MyDrive/RSNA_DATA/C3_Z26_C3_ROI_V2_PILOTS/runs/`.

## Decision rule

Compare B and C against the locked Fold 1 baseline MAE 6.253462. Keep a pilot
only if clean validation MAE improves and paired bootstrap evaluation on a
separate artifact validation view does not show a degradation. Do not use the
200-image RSNA test to choose between B and C.
